export class LoggingService{
    enviaMensajeAConsola(mensaje:string){
        console.log(mensaje);
    }
}